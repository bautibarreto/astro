"useer strict"

let i = 0, j = 0;
let tablaInicio = 1;
let tablaFin = 10;
let numeroInicio = 1;
let numeroFin = 10;
for (i = tablaInicio; i <= tablaFin; i++) {
    for (j = 1; j <= 10; j++) {
        console.log(i + " x " + j + " = " + i * j);
    }
}